public interface IWatchRequest {
    void addWatchRequest(WatchRequest request);
}