public class Medicine {
    private String medName;
    private int medStock;
    private int id;

    public Medicine(int id,String medName, int medStock) {
        this.setMedName(medName);
        this.setMedStock(medStock);
        this.setId(id);
    }

    public String getMedName() {
        return medName;
    }

    public void setMedName(String medName) {
        this.medName = medName;
    }

    public int getMedStock() {
        return medStock;
    }

    public void setMedStock(int medStock) {
        this.medStock = medStock;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
}
