public interface IDayOffRequest {

    void addDayOffRequest(DayOffRequest request);
}
