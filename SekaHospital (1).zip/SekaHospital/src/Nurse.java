import java.util.ArrayList;

public class Nurse extends HealthCareStaff implements  IMedicineRequest {

    public Nurse(String name, String id, String gender, String birthday, String registryNumber, double salary,
                 String startingDate, Policlinic policlinic, int watchCount, int dayOffCount, String mail) {
        super(name, id, gender, birthday, registryNumber, salary, startingDate, policlinic, watchCount, dayOffCount, mail);
        // TODO Auto-generated constructor stub
    }
    public Nurse(String name, String id, String gender, String birthday, double salary,
                 String startingDate, Policlinic policlinic, int watchCount, int dayOffCount, String mail) {
        super(name, id, gender, birthday, salary, startingDate, policlinic, watchCount, dayOffCount, mail);
        // TODO Auto-generated constructor stub
    }

    public void dispense(Medicine medicine) {
    medicine.setMedStock(medicine.getMedStock()-1);
    //String client="update medicine set stock =" +medicine.getMedStock() + "where name= '" + medicine.getMedName()+"'";
    //"update "+table+" set " + column + " = '" + value + "' where " + client + " = " + filter
    dbHelper.updateData("medicine","stock",String.valueOf(medicine.getMedStock()),"id",String.valueOf(medicine.getId()));  
   }
    
    

    @Override
    public double calculateSalary(String regNo) {
        ArrayList<ArrayList> infoDB = dbHelper.selectData("healthcarestaff","regNo,dayOffCount,watchCount");
        for(ArrayList<String> data : infoDB){
            String a = data.get(0).trim();
            if(a.equals(regNo)){
                int dayOffCount = Integer.valueOf(data.get(1));
                int watchCount = Integer.valueOf(data.get(2));
                return (30-dayOffCount)*250+watchCount*100;                
            }
        }
        return 0;
    }



    @Override
    public void addMedicineRequest(MedicineRequest medReq) {
        dbHelper.createNewData("insert into request (regNo,requestedMedicineId,description) values (" 
            +"'"+this.getRegistryNumber()+"',"+"'"+String.valueOf(medReq.getMedicine().getId()) +"',"
               +"'"+medReq.getExplanation()+"')");
    }

}
