import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.MessagingException;

public class Admin extends Employee implements IViewPatients {

    private ArrayList<HealthCareStaff> employees = new ArrayList<HealthCareStaff>();
    private ArrayList<Location> locations = new ArrayList<Location>(); // Şimdilik
    private ArrayList<Request> waitingRequest = new ArrayList<Request>();


    public Admin(String name, String id, String gender, String birthday, String registryNumber, double salary, String startingDate) {
        super(name, id, gender, birthday, registryNumber, salary, startingDate);
    }

    @Override
public double calculateSalary(String regNo) {
        ArrayList<ArrayList> infoDB = dbHelper.selectData("healthcarestaff","regNo,dayOffCount,watchCount");
        for(ArrayList<String> data : infoDB){
            String a = data.get(0).trim();
            if(a.equals(regNo)){
                int dayOffCount = Integer.valueOf(data.get(1));
                int watchCount = Integer.valueOf(data.get(2));
                return (30-dayOffCount)*400+watchCount*200;                
            }
        }
        return 0;
    }

    public void addEmployee(HealthCareStaff hcs) { // Person, poliklinik adı , maaşı , izin ve nöbet günü parametre olarak alsın.
        // poliklinik adını veritabanını sorgulayıp poliklinik bilgilerini çektikten sonra o polikliniği new'leyelim.
        // new healthcarestaff'a parametre olarak gönderelim.

        String pattern = "dd.MM.yyyy";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        String date = simpleDateFormat.format(new Date());
        System.out.println(date);
        hcs.setStartingDate(date);
        hcs.setSalary(hcs.calculateSalary(hcs));
        String s = Double.toString(hcs.getSalary());
        
        String client = "";
        String doc = Integer.toString(hcs.getDayOffCount());
        String wc = Integer.toString(hcs.getWatchCount());
        String rn=createRN(hcs);
        hcs.setRegistryNumber(rn);
        if (hcs instanceof Specialist) {
            String doctorRoom=giveDoctorRoom((Specialist)hcs);
            client = "insert into healthcarestaff (personalId,regNo,name,gender,birthday," +
                    "startingDate,salary,policlinic,dayOffCount,watchCount,doctorRoom,mailAdress) values (" + " ' " +
                    hcs.getId() + " ', " + " ' " + rn + " ', " + " ' " + hcs.getName() + " ', " + " ' " + hcs.getGender() + " ', " +
                    " ' " + hcs.getBirthday() + " ', " + " ' " + hcs.getStartingDate() + " ', " + " ' " + s + "', "
                    + " ' " + hcs.getPoliclinic().getPoliclinicName() + " ', " + " ' " + doc + " ', " + " ' " +
                    wc + " ', " + " ' " + doctorRoom + " ', " + "'"+ hcs.getMail()+   "')";

        } else {
            client = "insert into healthcarestaff (personalId,regNo,name,gender,birthday," +
                    "startingDate,salary,policlinic,dayOffCount,watchCount,mailAdress,doctorRoom) values (" + " ' " +
                    hcs.getId() + " ', " + " ' " + rn + " ', " + " ' " + hcs.getName() + " ', " + " ' " + hcs.getGender() + " ', " +
                    " ' " + hcs.getBirthday() + " ', " + " ' " + hcs.getStartingDate() + " ', " + " ' " + s + " ', "
                    + " ' " + hcs.getPoliclinic().getPoliclinicName() + " ', " + " ' " + doc + " ', " +
                    wc + ",'"+hcs.getMail()+"',0)";

        }
        dbHelper.createNewData(client);
        try {
            MailSender.send(hcs.getMail(),hcs.getRegistryNumber());
        } catch (MessagingException ex) {
            Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
        }
        //dbHelper.createNewData(client);
    }

    public String createRN(Employee employee) { // id ve çalışan tipini parametre olarak alsın.
        String userId = "NaN";
        String emploType = "NaN";
        if (employee instanceof Specialist) {
            emploType = "D1";
        } else if (employee instanceof Practitioner) {
            emploType = "D2";
        } else {
            emploType = "N1";
        }
        userId = emploType + employee.getId().substring(employee.getId().length() - 3);
        return userId;
    }

    public void answerRequest(Request request, boolean check) {
        HealthCareStaff hcs = request.getByWho(); // assignment made for reach the variable easier
        if (request instanceof DayOffRequest) { // Written for dayOffRequests
            ArrayList<ArrayList> requestFromDb = dbHelper.selectData("request", "id,regNo,requestedDayOff,description", "regNo= " +
                    hcs.getRegistryNumber()); // taking the certain request from database to store its database id.
            if (check) {// If request is accepted from admin
                hcs.setDayOffCount(hcs.getDayOffCount() + ((DayOffRequest) request).getDayOffCount()); // updating dayOffCount
                //hcs.setSalary(hcs.calculateSalary()); // Updating the salary due to change

                // Updating hcs' datas
                dbHelper.updateData("healthcarestaff", "salary", Double.toString(hcs.getSalary()), "regNo", hcs.getRegistryNumber());
                dbHelper.updateData("healthcarestaff", "dayOffCount", Integer.toString(hcs.getDayOffCount()), "regNo", hcs.getRegistryNumber());
            }
            // Deleting the request from db
            dbHelper.deleteData("request", "id", String.valueOf(requestFromDb.get(0).get(0)));

        } else if (request instanceof WatchRequest) { // Similar things for WatchRequest type requests
            ArrayList<ArrayList> requestFromDb = dbHelper.selectData("request", "id,regNo,requestedWatchRequest,description", "regNo =" +
                    hcs.getRegistryNumber());

            if (check) {// If request is accepted from admin
                hcs.setWatchCount(hcs.getWatchCount() + ((WatchRequest) request).getWatchCount()); // updating watchCount
                //hcs.setSalary(hcs.calculateSalary()); // Updating the salary due to change

                // Updating hcs' datas
                dbHelper.updateData("healthcarestaff", "salary", Double.toString(hcs.getSalary()), "regNo", hcs.getRegistryNumber());
                dbHelper.updateData("healthcarestaff", "watchCount", Integer.toString(hcs.getWatchCount()), "regNo", hcs.getRegistryNumber());
            }
            // Deleting the request from db
            dbHelper.deleteData("request", "id", (String) requestFromDb.get(0).get(0));

        } else { // Medicine request
            Medicine mdc = ((MedicineRequest) request).getMedicine();
            ArrayList<ArrayList> requestedMed = dbHelper.selectData("medicine", "id,name,stock", "id=" + mdc.getId());
            String medId = String.valueOf( requestedMed.get(0).get(0)); // taking medicine id of certain medicine
            ArrayList<ArrayList> requestFromDb = dbHelper.selectData("request", "id,regNo,requestedMedicineId,description",
                    "requestedMedicineId = " + medId); // taking certain request from db by its medicine id
            if (check) {// If request accepted, update the medicine stock
                dbHelper.updateData("medicine", "stock", "500", "id", medId);
            }//Then delete the certain request from db
            dbHelper.deleteData("request", "requestedMedicineId", medId);
        }

    }

    public ArrayList<ArrayList> viewEmployee() {
        return dbHelper.selectData("healthcarestaff", "personalId,regNo,name,gender,birthday," +
                "startingDate,salary,policlinic,dayOffCount,watchCount,doctorRoom");
    }

    @Override
    public ArrayList<ArrayList> viewPatients() {
        return dbHelper.selectData("patient", "personalId,name,gender,birthday," +
                "height,weight,bloodGroup,medicinesId,diagnosisId,doctorsId,roomId");
    }

    public String giveDoctorRoom(Specialist specialist) {
        String polName=specialist.getPoliclinic().getPoliclinicName();
       ArrayList<ArrayList> polsFromDb=dbHelper.selectData("policlinic","id,policlinicName");
       ArrayList<String> takenPol=new ArrayList<String>();
       for(ArrayList<String>pols:polsFromDb){
           if(pols.get(1).equals(polName)){
               takenPol.add(pols.get(0));
               takenPol.add(pols.get(1));
               break;
           }

       }
       ArrayList<ArrayList> roomsFromDb=dbHelper.selectData("location","id,roomName,policlinicId,doctorId");
       System.out.print(roomsFromDb);
        for(ArrayList<String> rooms:roomsFromDb){
            
            if(rooms.get(3).equals("0") && rooms.get(2).equals(takenPol.get(0))){
                dbHelper.updateData("location","doctorId",specialist.getRegistryNumber(),"id", rooms.get(0));
                return rooms.get(1);

            }
        }
        return "";
    }
    //@Override
    //public void viewPatients() {
    // Yatan veya yatmayan tüm hastalar veritabanından çekilerek burada görüntülenecek.
    //}
}