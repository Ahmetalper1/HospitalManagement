import java.util.ArrayList;

public class ChestDiseases extends Policlinic {


    public ChestDiseases( String policlinicName, ArrayList<Location> locations) {
        super(policlinicName,locations);
    }
    public ChestDiseases(String policlinicName){
        super(policlinicName);
    }
}