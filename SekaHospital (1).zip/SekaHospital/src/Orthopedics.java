import java.util.ArrayList;

public class Orthopedics extends Policlinic{

    public Orthopedics( String policlinicName, ArrayList<Location> locations) {
        super(policlinicName,locations);
    }
    public Orthopedics(String policlinicName){
        super(policlinicName);
    }

}