import java.util.ArrayList;

public interface IViewPatients {
    ArrayList<ArrayList> viewPatients();
}
