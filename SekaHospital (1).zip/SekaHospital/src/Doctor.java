
import java.sql.*;
import java.util.ArrayList;

public class Doctor extends HealthCareStaff implements IViewPatients {

    public Doctor(String name, String id, String gender, String birthday, String registryNumber, double salary,
            String startingDate, Policlinic policlinic, int watchCount, int dayOffCount, String mail) {
        super(name, id, gender, birthday, registryNumber, salary, startingDate, policlinic, watchCount, dayOffCount, mail);
    }
    public Doctor(String name, String id, String gender, String birthday, double salary,
            String startingDate, Policlinic policlinic, int watchCount, int dayOffCount, String mail) {
        super(name, id, gender, birthday, salary, startingDate, policlinic, watchCount, dayOffCount, mail);
    }

    // function to add diagnosis to patientss
    public void addDiagnosis(String personalId, String diagnosisId,String doctorId) throws SQLException {

        ArrayList<ArrayList> patientFromDB = dbHelper.selectData("patient", "id,diagnosisId,doctorsId", "personalId=" + personalId);
        String diagnosisFromDB = (String) patientFromDB.get(0).get(1);
        diagnosisFromDB = diagnosisFromDB + "-" + diagnosisId;
        String doctorsIdFromDB= (String) patientFromDB.get(0).get(2);
        if(!doctorsIdFromDB.contains(doctorId)){
            doctorsIdFromDB=doctorsIdFromDB+"-"+doctorId;
        }
        dbHelper.updateData("patient", "diagnosisId", diagnosisFromDB, "id", (String) patientFromDB.get(0).get(0));
        dbHelper.updateData("patient", "doctorsId", doctorsIdFromDB, "id", (String) patientFromDB.get(0).get(0));
    }

    // function to add medicine to patient
    public void addMedicine(String personalId, String medicineId,String doctorId) throws SQLException {

        ArrayList<ArrayList> patientFromDB = dbHelper.selectData("patient", "id,medicinesId,doctorsId", "personalId=" + personalId);
        String medicinesFromDB = (String) patientFromDB.get(0).get(1);
        medicinesFromDB = medicinesFromDB + "-" + medicineId;
        String doctorsIdFromDB= (String) patientFromDB.get(0).get(2);
        if(!doctorsIdFromDB.contains(doctorId)){
            doctorsIdFromDB=doctorsIdFromDB+"-"+doctorId;
        }
        dbHelper.updateData("patient", "medicinesId", medicinesFromDB, "id", (String) patientFromDB.get(0).get(0));
        dbHelper.updateData("patient", "doctorsId", doctorsIdFromDB, "id", (String) patientFromDB.get(0).get(0));

    }

    //function that checks for empty inpatient rooms in hospital
    public int giveRoomNumber() throws SQLException {

        ArrayList<ArrayList> emptyRoomsNo = dbHelper.selectData("inpatientroom", "id,isEmpty", "isEmpty=0");

        // if i is 51 it means there is no empty room in hospital because there are 50 room
        if (emptyRoomsNo.size() == 0) {
            return 0;
        } // if there is an empty room i is the number of the room
        else {
            return Integer.valueOf((String) emptyRoomsNo.get(0).get(0));
        }
    }

    // function to enroll the patient in the inpatient department
    public void makeInpatient(String personalId) throws SQLException {

        if (giveRoomNumber() != 0) {

            ArrayList<ArrayList> patientFromDB = dbHelper.selectData("patient", "id,roomId", "personalId=" + personalId);

            // to memorize the room number
            int roomNo = Integer.valueOf((String) patientFromDB.get(0).get(1));
            // checking is patient have a room and to place in the room if the patient does not have a room
            if (roomNo == 0) {

                dbHelper.updateData("patient", "roomId", Integer.toString(giveRoomNumber()), "id", (String) patientFromDB.get(0).get(0));
                dbHelper.updateData("inpatientroom", "isEmpty", "1", "id", Integer.toString(giveRoomNumber()));

            } // displays the information if the patient already has a room.
            else {
                System.out.println("Hasta zaten " + roomNo + " numaralı odada kalmaktadır");
            }
        } // If there is no empty room in the hospital, it displays the information.
        else {
            System.out.println("Yataklı hasta bölümünde boş yatak bulunmamaktadır.");
        }

    }

    // function to discharge the inpatient
    public void dischargeInpatient(String personalId) throws SQLException {

        ArrayList<ArrayList> patientFromDB = dbHelper.selectData("patient", "id,roomId", "personalId=" + personalId);

        // to memorize the room number
        int roomNo = Integer.valueOf((String) patientFromDB.get(0).get(1));
        // checking is patient have a room and to place in the room if the patient does not have a room
        if (roomNo != 0) {

            dbHelper.updateData("patient", "roomId", "0", "id", (String) patientFromDB.get(0).get(0));
            dbHelper.updateData("inpatientroom", "isEmpty", "0", "id", Integer.toString(roomNo));

        } // displays the information if the patient already has a room.
        else {
            System.out.println("Hasta zaten yatan hasta değildir");
        }
    }

    public ArrayList<ArrayList> viewInpatients() {
        ArrayList<ArrayList> inpatientsOfDoctor = null;
        for (ArrayList patient : viewPatients()) {
            if (((int) patient.get(7)) > 0) {
                inpatientsOfDoctor.add(patient);
            }
        }
        return inpatientsOfDoctor;
    }

    @Override
    public double calculateSalary(String regNo) {
        ArrayList<ArrayList> infoDB = dbHelper.selectData("healthcarestaff","regNo,dayOffCount,watchCount");
        for(ArrayList<String> data : infoDB){
            String a = data.get(0).trim();
            if(a.equals(regNo)){
                int dayOffCount = Integer.valueOf(data.get(1));
                int watchCount = Integer.valueOf(data.get(2));
                return (30-dayOffCount)*400+watchCount*200;                
            }
        }
        return 0;
    }

    public void addPatient(Patient patient) {
        String client = "insert into patient (personalId,name,gender,birthday,height,weight,"
                + "bloodGroup,medicinesId,diagnosisId,doctorsId,roomId) values ('" + patient.getId() + "', '"
                + patient.getName() + "', '" + patient.getGender() + "', '" + patient.getBirthday() + "', '"
                + patient.getHeight() + "', '" + patient.getWeight() + "', '" + patient.getBloodGroup() + "', '"
                + patient.getMedicines() + "', '" + patient.getDiagnosis() + "', '" + patient.getDoctors() + "', '" + patient.getRoomId() + "')";
        DbHelper dataBase = new DbHelper();
        dataBase.createNewData(client);
        System.out.println(client);
    }

    @Override
    public ArrayList<ArrayList> viewPatients() {
        ArrayList<ArrayList> patientsOfDoctor = new ArrayList<ArrayList>();
        ArrayList<ArrayList> patients = new ArrayList<ArrayList>();
        DbHelper dbHelper = new DbHelper();
        patients = dbHelper.selectData("patient", "personalId,name,birthday,height,weight,diagnosisId,doctorsId,roomId");
        for (ArrayList<String> patient : patients) {
             if(patient.get(6).contains(this.getId())){
                 patientsOfDoctor.add(patient);
             }
             System.out.print(patient);
        }
        System.out.print(patientsOfDoctor);
        return patientsOfDoctor;

    }
    public ArrayList<ArrayList> viewAllPatients() {
        
        ArrayList<ArrayList> patients = new ArrayList<ArrayList>();
        DbHelper dbHelper = new DbHelper();
        patients = dbHelper.selectData("patient", "personalId,name,birthday,height,weight,diagnosisId,doctorsId,roomId");
        //System.out.print(patients);
        
        return patients;

    }

}
