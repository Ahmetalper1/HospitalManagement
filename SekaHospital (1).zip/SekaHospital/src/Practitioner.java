import java.util.ArrayList;

public class Practitioner extends Doctor{

    public Practitioner(String name, String id, String gender, String birthday, String registryNumber, double salary,
                        String startingDate, Policlinic policlinic,int watchCount,int dayOffCount, String mail) {
        super(name, id, gender, birthday, registryNumber, salary, startingDate, policlinic, watchCount, dayOffCount, mail);
        // TODO Auto-generated constructor stub
    }
    public Practitioner(String name, String id, String gender, String birthday, double salary,
                        String startingDate, Policlinic policlinic,int watchCount,int dayOffCount, String mail) {
        super(name, id, gender, birthday, salary, startingDate, policlinic, watchCount, dayOffCount, mail);
        // TODO Auto-generated constructor stub
    }

    @Override
    public double calculateSalary(String regNo) {
        ArrayList<ArrayList> infoDB = dbHelper.selectData("healthcarestaff","regNo,dayOffCount,watchCount");
        for(ArrayList<String> data : infoDB){
            String a = data.get(0).trim();
            if(a.equals(regNo)){
                int dayOffCount = Integer.valueOf(data.get(1));
                int watchCount = Integer.valueOf(data.get(2));
                return (30-dayOffCount)*400+watchCount*200;                
            }
        }
        return 0;
    }

}
