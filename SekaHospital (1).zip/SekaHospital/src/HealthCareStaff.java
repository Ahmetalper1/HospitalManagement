
import java.util.ArrayList;


public class HealthCareStaff extends Employee implements IWatchRequest,IDayOffRequest {

    private Policlinic policlinic;
    private int watchCount = 0;
    private int dayOffCount = 0;
    private String mail;


    public HealthCareStaff(String name, String id, String gender, String birthday, String registryNumber, double salary,
                           String startingDate, Policlinic policlinic, int watchCount, int dayOffCount, String mail) {
        super(name, id, gender, birthday, registryNumber, salary, startingDate);
        //this.setSalary(calculateSalary());
        this.mail=mail;
        this.watchCount = watchCount;
        this.dayOffCount = dayOffCount;
        this.policlinic = policlinic;
    }
    public HealthCareStaff(String name, String id, String gender, String birthday, double salary,
                           String startingDate, Policlinic policlinic, int watchCount, int dayOffCount, String mail) {
        super(name, id, gender, birthday, salary, startingDate);
        //this.setSalary(calculateSalary());
        this.mail=mail;
        this.watchCount = watchCount;
        this.dayOffCount = dayOffCount;
        this.policlinic = policlinic;
    }

    public double mySalary() {
        return 50;
    }

    @Override
    public double calculateSalary(String regNo) {
        ArrayList<ArrayList> infoDB = dbHelper.selectData("healthcarestaff","regNo,dayOffCount,watchCount");
        for(ArrayList<String> data : infoDB){
            String a = data.get(0).trim();
            if(a.equals(regNo)){
                int dayOffCount = Integer.valueOf(data.get(1));
                int watchCount = Integer.valueOf(data.get(2));
                return (30-dayOffCount)*400+watchCount*200;                
            }
        }
        return 0;
    }
    public double calculateSalary(HealthCareStaff hcs) {
        return (30-hcs.getDayOffCount())*400+hcs.getWatchCount()*200;
    }

    public Policlinic getPoliclinic() {
        int a = 367;
        return policlinic;
    }

    public void setPoliclinic(Policlinic policlinic) {
        this.policlinic = policlinic;
    }

    public int getWatchCount() {
        return watchCount;
    }

    public void setWatchCount(int watchCount) {
        this.watchCount = watchCount;
    }

    public int getDayOffCount() {
        return dayOffCount;
    }

    public void setDayOffCount(int dayOffCount) {
        this.dayOffCount = dayOffCount;
    }

    @Override
    public void addDayOffRequest(DayOffRequest request) {
        dbHelper.createNewData("insert into request (regNo,requestedDayOff,description) values ('"+this.getRegistryNumber()+"','"+request.getDayOffCount()+"','"+request.getExplanation()+"')");
    }

    @Override
    public void addWatchRequest(WatchRequest request) {
        dbHelper.createNewData("insert into request (regNo,requestedWatch,description) values ('"+this.getRegistryNumber()+"','"+request.getWatchCount()+"','"+request.getExplanation()+"')");
    }

    /**
     * @return the mail
     */
    public String getMail() {
        return mail;
    }

    /**
     * @param mail the mail to set
     */
    public void setMail(String mail) {
        this.mail = mail;
    }
}
