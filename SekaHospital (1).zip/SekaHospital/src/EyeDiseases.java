import java.util.ArrayList;

public class EyeDiseases extends Policlinic {
    public EyeDiseases( String policlinicName, ArrayList<Location> locations) {
    super(policlinicName,locations);
}
    public EyeDiseases(String policlinicName){
        super(policlinicName);
    }
}