public interface IMedicineRequest {
    void addMedicineRequest(MedicineRequest medReq);
}