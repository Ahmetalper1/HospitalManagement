import com.google.zxing.WriterException;
import java.util.HashMap;
import java.util.Map;
import java.io.IOException;
import java.util.*;
import javax.mail.*;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.*;

public class MailSender {

    public static void send(String recipientMail, String recipientRegistryNumber)
            throws AddressException, MessagingException {
        final String accountEmail = "seka.hospital.officall@gmail.com";
        final String password = "smtdgn3000";
        Properties properties = new Properties(); // status of connection mail service
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.user", accountEmail);
        properties.put("mail.password", password);

        // creates a new session with an authenticator
        Authenticator auth = new Authenticator() {
            public PasswordAuthentication getPasswordAuthentication() { // login account
                return new PasswordAuthentication(accountEmail, password);
            }
        };
        try {
            System.out.print("ss");
            QRCode.generate(recipientRegistryNumber);
        } catch (WriterException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Session session = Session.getInstance(properties, auth);

        // creates a new e-mail message
        Message msg = new MimeMessage(session);
        msg.setFrom(new InternetAddress(accountEmail));
        msg.setRecipient(Message.RecipientType.TO, new InternetAddress(recipientMail));
        msg.setSubject("Registry Number");
        msg.setSentDate(new Date());

        StringBuffer htmlBody = new StringBuffer("<html>Your Registry Number is: "+recipientRegistryNumber+" .<br>");
        Map<String, String> mapInlineImages = new HashMap<String, String>();
        //C:\Users\samet\Documents\NetBeansProjects\SekaHospital
        mapInlineImages.put("image1", "C:/Users/samet/Documents/NetBeansProjects/SekaHospital/QRCode.png");
        htmlBody.append("Your QR Code:<br>");
        htmlBody.append("<img src=\"cid:image1\" width=\"100%\" height=\"100%\" /><br>");
        htmlBody.append("</html>");

        // creates message part
        MimeBodyPart messageBodyPart = new MimeBodyPart();
        messageBodyPart.setContent(htmlBody.toString(), "text/html");

        // creates multi-part
        Multipart multipart = new MimeMultipart();
        multipart.addBodyPart(messageBodyPart);

        // adds inline image attachments
        if (mapInlineImages != null && mapInlineImages.size() > 0) {
            Set<String> setImageID = mapInlineImages.keySet();

            for (String contentId : setImageID) {
                MimeBodyPart imagePart = new MimeBodyPart();
                imagePart.setHeader("Content-ID", "<" + contentId + ">");
                imagePart.setDisposition(MimeBodyPart.INLINE);

                String imageFilePath = mapInlineImages.get(contentId);
                try {
                    imagePart.attachFile(imageFilePath);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }

                multipart.addBodyPart(imagePart);
            }
        }

        msg.setContent(multipart);

        Transport.send(msg);
    }
}
