import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
public class AdminViewPatient extends javax.swing.JFrame {

    private Admin admin;
        
    public AdminViewPatient() {
        initComponents();
        
        //Constructor da table doldur 
    }
    public void listPatient(){
        DbHelper helper= new DbHelper();
        DefaultTableModel model = (DefaultTableModel)jPatientTable.getModel();
        //Arraylist<Medicine>"personalId,name,gender,birthday," +
                //"height,weight,bloodGroup,medicinesId,diagnosisId,doctorsId,roomId"
        for(ArrayList<ArrayList> patient : admin.viewPatients()){
            Object[] row = {
                patient.get(0),
                patient.get(1),
                patient.get(3),
                patient.get(9),
                patient.get(10)
            };
            model.addRow(row);
        }
    }
    public Admin getAdmin(){
     return admin;
     }
    public void setAdmin(Admin admin){
     this.admin=admin;
     }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jViewEmployeeLabel = new javax.swing.JLabel();
        jAddEmployeeLabel = new javax.swing.JLabel();
        jMyAccountLabel = new javax.swing.JLabel();
        jAnswerRequestLabel = new javax.swing.JLabel();
        jViewPatientLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPatientTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(800, 450));
        setPreferredSize(new java.awt.Dimension(850, 400));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setPreferredSize(new java.awt.Dimension(800, 450));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jViewEmployeeLabel.setText("View Employee");
        jViewEmployeeLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jViewEmployeeLabelMouseClicked(evt);
            }
        });
        jPanel1.add(jViewEmployeeLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 71, 78, 20));

        jAddEmployeeLabel.setText("Add Employee");
        jAddEmployeeLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jAddEmployeeLabelMouseClicked(evt);
            }
        });
        jPanel1.add(jAddEmployeeLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 103, 78, 20));

        jMyAccountLabel.setText("My Account");
        jMyAccountLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMyAccountLabelMouseClicked(evt);
            }
        });
        jPanel1.add(jMyAccountLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, 80, 20));

        jAnswerRequestLabel.setText("Answer Request");
        jAnswerRequestLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jAnswerRequestLabelMouseClicked(evt);
            }
        });
        jPanel1.add(jAnswerRequestLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 135, -1, 20));

        jViewPatientLabel.setText("View Patient");
        jViewPatientLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jViewPatientLabelMouseClicked(evt);
            }
        });
        jPanel1.add(jViewPatientLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 78, 30));

        jPatientTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Identity Number", "Name", "Birthday", "Doctors", "Room Id"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jPatientTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jPatientTable);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 40, -1, 305));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 810, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jViewPatientLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jViewPatientLabelMouseClicked

    }//GEN-LAST:event_jViewPatientLabelMouseClicked

    private void jViewEmployeeLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jViewEmployeeLabelMouseClicked
    AdminViewEmployee nfd1= new  AdminViewEmployee();
     nfd1.setAdmin(this.getAdmin());
     nfd1.listEmployee();
     nfd1.setVisible(true);
     this.setVisible(false);
    }//GEN-LAST:event_jViewEmployeeLabelMouseClicked

    private void jAddEmployeeLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jAddEmployeeLabelMouseClicked
    AdminAddEmployee nfd2= new  AdminAddEmployee();
     nfd2.setAdmin(this.getAdmin());
     nfd2.setVisible(true);
     this.setVisible(false);
    }//GEN-LAST:event_jAddEmployeeLabelMouseClicked

    private void jAnswerRequestLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jAnswerRequestLabelMouseClicked
    AdminAnswerRequest nfd3= new AdminAnswerRequest();
     nfd3.setAdmin(this.getAdmin());
     nfd3.setVisible(true);
     this.setVisible(false);
    }//GEN-LAST:event_jAnswerRequestLabelMouseClicked

    private void jMyAccountLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMyAccountLabelMouseClicked
    AdminMyAccount nfd4= new AdminMyAccount();
     nfd4.setAdmin(this.getAdmin());
     nfd4.listMyAccount();
     nfd4.setVisible(true);
     this.setVisible(false);
    }//GEN-LAST:event_jMyAccountLabelMouseClicked
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminViewPatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminViewPatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminViewPatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminViewPatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminViewPatient().setVisible(true);
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jAddEmployeeLabel;
    private javax.swing.JLabel jAnswerRequestLabel;
    private javax.swing.JLabel jMyAccountLabel;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTable jPatientTable;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel jViewEmployeeLabel;
    private javax.swing.JLabel jViewPatientLabel;
    // End of variables declaration//GEN-END:variables
}
